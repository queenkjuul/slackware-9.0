/*
 * %W% %G%
 *
 * User interface for setting database preferences.
 */
static char *ident = "%W% %G%";

#include <xview/xview.h>
#include "workman_ui.h"

void
show_db_prefs(menu, menu_item)
	Menu		menu;
	Menu_item	menu_item;
{
}
