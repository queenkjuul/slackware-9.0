/* "@(#)patchlevel.h 1.11 93/11/04 */

#define SSPKG_PATCHLEVEL 0
#define SSPKG_VERSION 2.1

