/* version.h   */

#ifndef VERSION_H
#define VERSION_H
			/* retail */
#define VERSION_MAJOR 22
#define VERSION_MINOR 5
#define VERSION_EDIT  ""
#define VERSION_DATE "04-Mar-2003"

#endif
