#define MANVERSION              1
#define MANREVISION             1
#define BUILD_NUMBER            1

#define VERSIONSTR    "Voodoo2 InitCode " "$Revision: 1.2 $" "\0"
