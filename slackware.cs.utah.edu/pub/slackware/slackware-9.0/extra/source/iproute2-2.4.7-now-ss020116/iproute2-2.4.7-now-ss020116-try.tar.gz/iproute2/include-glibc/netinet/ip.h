#ifndef __NETINET_IP_H
#define __NETINET_IP_H 1

#include <glibc-bugs.h>
#include <netinet/in.h>

#include <linux/ip.h>

#endif /* netinet/ip.h */
