static char SNAPSHOT[] = "020116";
