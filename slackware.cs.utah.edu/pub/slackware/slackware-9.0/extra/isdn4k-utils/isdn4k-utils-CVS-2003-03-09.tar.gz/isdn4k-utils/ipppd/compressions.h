
char *compression_names[256] = {
 "OUI", "Predictor type 1", "Predictor type 2", "Puddle Jumper",
 NULL, NULL, NULL, NULL,
 NULL, NULL, NULL, NULL,
 NULL, NULL, NULL, NULL,
 "Hewlett-Packard PPC", "Stac Electronics LZS", "Microsoft PPC", "Gandalf FZA",
 "V.42bis compression", "BSD Compress", NULL, "LZS-DCP",
 "MVRCA (Magnalink)", "DCE", "Deflate", NULL,
};

