/* $Id: patchlevel.h,v 1.2 2001/05/03 09:00:51 calle Exp $ */
#define	PATCHLEVEL	0

#define VERSION		"2.4"
#define IMPLEMENTATION	""
#define DATE		"1 August 2000"
