/*
** $Id: vboxctrl.h,v 1.1 1997/02/26 13:10:55 michael Exp $
**
** Copyright (C) 1996, 1997 Michael 'Ghandi' Herold
*/

#ifndef _VBOX_CTRL_H
#define _VBOX_CTRL_H 1

#endif /* _VBOX_CTRL_H */
