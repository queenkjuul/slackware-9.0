/*
** $Id: vboxgetty.h,v 1.5 1997/05/10 10:59:00 michael Exp $
**
** Copyright (C) 1996, 1997 Michael 'Ghandi' Herold
*/

#ifndef _VBOX_GETTY_H
#define _VBOX_GETTY_H 1

/** Variables ************************************************************/

extern char *vbasename;

/** Prototypes ***********************************************************/

extern void block_all_signals(void);

#endif /* _VBOX_GETTY_H */
