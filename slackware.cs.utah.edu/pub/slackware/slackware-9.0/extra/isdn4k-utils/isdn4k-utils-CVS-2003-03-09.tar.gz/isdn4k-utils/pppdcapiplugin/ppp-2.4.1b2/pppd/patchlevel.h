/* $Id: patchlevel.h,v 1.1 2001/05/03 09:00:52 calle Exp $ */

#define VERSION		"2.4.1b2"
#define DATE		"13 March 2001"
