/* config.h.  Generated automatically by configure.  */
/* configure sets these don't change */

/* #undef HAVE_LIBGDBM */
/* #undef HAVE_LIBDBM */
/* #undef HAVE_LIBDB */
#define USE_CDB 1

#define RDBEXT ".cdb"

#define SIZEOF_CHAR 1
#define SIZEOF_SHORT 2
#define SIZEOF_INT 4
#define SIZEOF_LONG 4
