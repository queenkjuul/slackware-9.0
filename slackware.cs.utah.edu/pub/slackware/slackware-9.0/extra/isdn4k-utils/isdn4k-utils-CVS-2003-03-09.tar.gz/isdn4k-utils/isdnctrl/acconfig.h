/* Define this if your system has the old dbm library. */
#undef HAVE_LIBDBM

/* Define this if your system has the GNU dbm library. */
#undef HAVE_LIBGDBM

/* Define this if triggercps is defined in struct isdn_net_ioctl_cfg. */
#undef HAVE_TRIGGERCPS

/* Define this if ISDN_ENCAP_CISCOHDLCK is defined in isdn.h. */
#undef HAVE_CISCOKEEPALIVE

/* Define this, if TIMRU extension is available */
#undef HAVE_TIMRU
