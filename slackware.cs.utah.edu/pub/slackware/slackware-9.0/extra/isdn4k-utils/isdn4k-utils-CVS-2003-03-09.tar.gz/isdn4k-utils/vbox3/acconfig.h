
/* Define this if you have siginterrupt().  */
#undef HAVE_SIGINTERRUPT

/* Version number and package name.  */
#undef VERSION
#undef PACKAGE
