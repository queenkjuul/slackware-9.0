# SOME DESCRIPTIVE TITLE.
# Copyright (C) YEAR Free Software Foundation, Inc.
# FIRST AUTHOR <EMAIL@ADDRESS>, YEAR.
#
#, fuzzy
msgid ""
msgstr ""
"Project-Id-Version: PACKAGE VERSION\n"
"POT-Creation-Date: 2001-09-29 12:21-0700\n"
"PO-Revision-Date: YEAR-MO-DA HO:MI+ZONE\n"
"Last-Translator: FULL NAME <EMAIL@ADDRESS>\n"
"Language-Team: LANGUAGE <LL@li.org>\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=CHARSET\n"
"Content-Transfer-Encoding: ENCODING\n"

#: src/accounting.c:39
#, c-format
msgid "Do_accounting: pagecounter %d"
msgstr ""

#: src/accounting.c:41
#, c-format
msgid "Do_accounting: pagecounter %d, pages %d"
msgstr ""

#: src/accounting.c:112
msgid "ACCOUNTING"
msgstr ""

#: src/accounting.c:116
#, c-format
msgid "Do_accounting: script '%s' failed"
msgstr ""

#: src/ifhp.c:116
msgid "ifhp: stdin is not open"
msgstr ""

#: src/ifhp.c:120
msgid "ifhp: stdout is not open"
msgstr ""

#: src/ifhp.c:125
msgid "ifhp: open /dev/null failed"
msgstr ""

#: src/ifhp.c:178
msgid "TRANSLATE TEST"
msgstr ""

#: src/ifhp.c:183
#, c-format
msgid "main: no readable config file found in '%s'"
msgstr ""

#: src/ifhp.c:188
#, c-format
msgid "main: no config file information in '%s'"
msgstr ""

#: src/ifhp.c:202
#, c-format
msgid "main: no model '%s' information"
msgstr ""

#: src/ifhp.c:250
msgid "main: you opened the statusfile too early!!!"
msgstr ""

#: src/ifhp.c:254
#, c-format
msgid "main: using model '%s'"
msgstr ""

#: src/ifhp.c:254
msgid "DEFAULT"
msgstr ""

#: src/ifhp.c:572
#, c-format
msgid "Put_outbuf_len: realloc %d failed"
msgstr ""

#: src/ifhp.c:643
#, c-format
msgid "Pr_status: printer status '%s'"
msgstr ""

#: src/ifhp.c:781
#, c-format
msgid "Check_device_status: code = %s, '%s'%s"
msgstr ""

#: src/ifhp.c:786
#, c-format
msgid "Check_device_status: write(fd %d) failed"
msgstr ""

#: src/ifhp.c:790
msgid "Check_device_status: lseek failed"
msgstr ""

#: src/ifhp.c:792
msgid "ALERT"
msgstr ""

#: src/ifhp.c:801
msgid "status"
msgstr ""

#: src/ifhp.c:802
msgid "error"
msgstr ""

#: src/ifhp.c:803
msgid "offending"
msgstr ""

#: src/ifhp.c:850
msgid "yes"
msgstr ""

#: src/ifhp.c:851
msgid "on"
msgstr ""

#: src/ifhp.c:895
msgid "Process_job: setting up printer"
msgstr ""

#: src/ifhp.c:900
msgid "Process_job: dup(0) failed"
msgstr ""

#: src/ifhp.c:904
msgid "Process_job: dup(1) failed"
msgstr ""

#: src/ifhp.c:907
msgid "Process_job: starting OF mode passthrough"
msgstr ""

#: src/ifhp.c:913
msgid "Process_job: lseek of tempfd failed"
msgstr ""

#: src/ifhp.c:917
msgid "Process_job: ftruncate of tempfd failed"
msgstr ""

#: src/ifhp.c:922
#, c-format
msgid "Process_job: tempfd dup2(%d,1) failed"
msgstr ""

#: src/ifhp.c:927
msgid "Process_job: stat failed"
msgstr ""

#: src/ifhp.c:934
msgid "Process_job: lseek failed"
msgstr ""

#: src/ifhp.c:938
msgid "Process_job: tempfd dup2() failed"
msgstr ""

#: src/ifhp.c:945 src/ifhp.c:981
#, c-format
msgid "Process_job: outfd dup2(%d,1) failed"
msgstr ""

#: src/ifhp.c:948
#, c-format
msgid "Process_job: sending %0.0f bytes of OF input"
msgstr ""

#: src/ifhp.c:955
msgid "Process_job: using shutdown on appsocket connection"
msgstr ""

#: src/ifhp.c:966
msgid "Process_job: OF process suspending"
msgstr ""

#: src/ifhp.c:972
msgid "Process_job: OF process running"
msgstr ""

#: src/ifhp.c:976
#, c-format
msgid "Process_job: infd dup2(%d,1) failed"
msgstr ""

#: src/ifhp.c:988
msgid "Process_job: ending OF mode passthrough"
msgstr ""

#: src/ifhp.c:992
msgid "Process_job: sending job file"
msgstr ""

#: src/ifhp.c:994
msgid "Process_job: sent job file"
msgstr ""

#: src/ifhp.c:998
msgid "Process_job: done"
msgstr ""

#: src/ifhp.c:1018
msgid "Start_of_job: fd 1 not open"
msgstr ""

#: src/ifhp.c:1071
msgid "Start_of_job: timeout"
msgstr ""

#: src/ifhp.c:1094
msgid "End_of_job: FD 1 IS CLOSED AND ifhp DID NOT CLOSE IT"
msgstr ""

#: src/ifhp.c:1121
msgid "End_of_job: timeout"
msgstr ""

#: src/ifhp.c:1407
msgid "plp_block_all_signals: sigprocmask failed"
msgstr ""

#: src/ifhp.c:1421
msgid "plp_unblock_all_signals: sigprocmask failed"
msgstr ""

#: src/ifhp.c:1431
msgid "plp_set_signal_mask: sigprocmask failed"
msgstr ""

#: src/ifhp.c:1449
msgid "plp_unblock_one_signal: sigprocmask failed"
msgstr ""

#: src/ifhp.c:1464
msgid "plp_block_one_signal: sigprocmask failed"
msgstr ""

#: src/ifhp.c:1627
msgid "Write_read_timeout: write error or timeout"
msgstr ""

#: src/ifhp.c:1647 src/ifhp.c:1742
msgid "Write_read_timeout: write error"
msgstr ""

#: src/ifhp.c:1698
msgid "Write_read_timeout: select error"
msgstr ""

#: src/ifhp.c:1709
msgid "Write_read_timeout: read from printer failed"
msgstr ""

#: src/ifhp.c:2060
#, c-format
msgid "Fix_option_str: bad form '%s'"
msgstr ""

#: src/ifhp.c:2198
#, c-format
msgid "Find_sub_value: bad conditional format '%s'"
msgstr ""

#: src/ifhp.c:2416
#, c-format
msgid "Font_download: no value for %sfontdir"
msgstr ""

#: src/ifhp.c:2431
msgid "Font_download: no 'font' value"
msgstr ""

#: src/ifhp.c:2744
#, c-format
msgid "Do_sync: sync '%s' and method not supported"
msgstr ""

#: src/ifhp.c:2750
#, c-format
msgid "Do_sync: getting sync using '%s'"
msgstr ""

#: src/ifhp.c:2797
#, c-format
msgid "Do_sync: sync '%s' and no ps_status_code value"
msgstr ""

#: src/ifhp.c:2820
msgid "Do_sync: no way to synchronize printer, need PJL, or PS"
msgstr ""

#: src/ifhp.c:2871
msgid "Do_sync: sync done"
msgstr ""

#: src/ifhp.c:2939
#, c-format
msgid "Do_waitend: waitend '%s' and method not supported"
msgstr ""

#: src/ifhp.c:2946
#, c-format
msgid "Do_waitend: getting end using '%s'"
msgstr ""

#: src/ifhp.c:3091
#, c-format
msgid "Do_waitend: no end response from printer, timeout %d"
msgstr ""

#: src/ifhp.c:3093
#, c-format
msgid "Do_waitend: end of %s detected"
msgstr ""

#: src/ifhp.c:3093
msgid "banner page"
msgstr ""

#: src/ifhp.c:3093
msgid "job"
msgstr ""

#: src/ifhp.c:3154
#, c-format
msgid "Check_pagecount: pagecount '%s' and method not supported"
msgstr ""

#: src/ifhp.c:3157
msgid "pjl info pagecount"
msgstr ""

#: src/ifhp.c:3157
msgid "ps script"
msgstr ""

#: src/ifhp.c:3159
#, c-format
msgid "Check_pagecount: pagecount using '%s'"
msgstr ""

#: src/ifhp.c:3174
#, c-format
msgid "Do_pagecount: pagecounter %d, polling %d times at %d second intervals"
msgstr ""

#: src/ifhp.c:3191
#, c-format
msgid "Do_pagecount: pagecounter %d after %d attempts"
msgstr ""

#: src/ifhp.c:3235
msgid "Current_pagecounter: no ps_pagecount_code config info"
msgstr ""

#: src/ifhp.c:3300
#, c-format
msgid "Current_pagecounter: no pagecounter response from printer, timeout %d"
msgstr ""

#: src/ifhp.c:3357
msgid "Send_job: starting transfer"
msgstr ""

#: src/ifhp.c:3377 src/ifhp.c:3396 src/ifhp.c:3436 src/ifhp.c:3536
#: src/ifhp.c:3590 src/ifhp.c:3667
msgid "Send_job: lseek failed"
msgstr ""

#: src/ifhp.c:3388 src/ifhp.c:3599 src/ifhp.c:3702 src/ifhp.c:3836
msgid "Send_job: read error on stdin"
msgstr ""

#: src/ifhp.c:3391 src/ifhp.c:3705
msgid "Send_job: zero length job file"
msgstr ""

#: src/ifhp.c:3407
msgid "Send_job: missing file_util_path value"
msgstr ""

#: src/ifhp.c:3439
#, c-format
msgid "Send_job: initial job type '%s'"
msgstr ""

#: src/ifhp.c:3454
#, c-format
msgid "Send_job: could not open '%s'"
msgstr ""

#: src/ifhp.c:3474
#, c-format
msgid "Send_job: wrong number of fields in 'file_output_match' - '%s'"
msgstr ""

#: src/ifhp.c:3490
#, c-format
msgid "Send_job: decoded job type '%s'"
msgstr ""

#: src/ifhp.c:3496
#, c-format
msgid "Send_job: MSG '%s'"
msgstr ""

#: src/ifhp.c:3500
msgid "Send_job: job is PJL and PJL not supported"
msgstr ""

#: src/ifhp.c:3505
msgid "Send_job: job is PCL and PCL not supported"
msgstr ""

#: src/ifhp.c:3510
msgid "Send_job: job is PostScript and PostScript not supported"
msgstr ""

#: src/ifhp.c:3515
msgid "Send_job: job is Text and Text not supported"
msgstr ""

#: src/ifhp.c:3521
msgid "Send_job: filter wanted and no filter specified"
msgstr ""

#: src/ifhp.c:3524
#, c-format
msgid "Send_job: cannot process language '%s'"
msgstr ""

#: src/ifhp.c:3532
#, c-format
msgid "Send_job: job type '%s', converter '%s'"
msgstr ""

#: src/ifhp.c:3548
msgid "CONVERTER"
msgstr ""

#: src/ifhp.c:3555
#, c-format
msgid "Send_job: converter failed, exit code %d"
msgstr ""

#: src/ifhp.c:3566
msgid "Send_job: fstat2 failed"
msgstr ""

#: src/ifhp.c:3568
#, c-format
msgid "Send_job: converter done, output %ld bytes"
msgstr ""

#: src/ifhp.c:3572
msgid "Send_job: zero length conversion output"
msgstr ""

#: src/ifhp.c:3577
msgid "Send_job: dup2 failed"
msgstr ""

#: src/ifhp.c:3581
#, c-format
msgid "Send_job: close(tempfd %d) failed"
msgstr ""

#: src/ifhp.c:3587
#, c-format
msgid "Send_job: job type '%s', stripping leading PJL "
msgstr ""

#: src/ifhp.c:3631
msgid "Send_job: write error to tempfile"
msgstr ""

#: src/ifhp.c:3640 src/ifhp.c:4086
msgid "Make_stdin_file: dup2 failed"
msgstr ""

#: src/ifhp.c:3646
#, c-format
msgid "Send_job: job type '%s'"
msgstr ""

#: src/ifhp.c:3662
msgid "Send_job: cannot fstat fd 0"
msgstr ""

#: src/ifhp.c:3686
#, c-format
msgid "Send_job: transferring %0.0f bytes"
msgstr ""

#: src/ifhp.c:3800
msgid "Send_job: job failed during copy"
msgstr ""

#: src/ifhp.c:3811 src/ifhp.c:3819
#, c-format
msgid "Send_job: %d percent done"
msgstr ""

#: src/ifhp.c:3821
#, c-format
msgid "Send_job: %d Kbytes done"
msgstr ""

#: src/ifhp.c:3849
msgid "Send_job: data sent"
msgstr ""

#: src/ifhp.c:3903
msgid "Process_OF_mode: ftruncate fd 1 failed"
msgstr ""

#: src/ifhp.c:3916 src/ifhp.c:3921 src/ifhp.c:3926
msgid "Process_OF_mode: write failed"
msgstr ""

#: src/ifhp.c:3975
#, c-format
msgid "Use_file_util: file program = '%s'"
msgstr ""

#: src/ifhp.c:3980 src/ifhp.c:3990
msgid "Use_file_util: lseek failed"
msgstr ""

#: src/ifhp.c:3983
msgid "FILE_UTIL"
msgstr ""

#: src/ifhp.c:3986
#, c-format
msgid "Use_file_util: exit code %d"
msgstr ""

#: src/ifhp.c:3994
msgid "Use_file_util: read failed"
msgstr ""

#: src/ifhp.c:4016
#, c-format
msgid "Use_file_util: file information = '%s'"
msgstr ""

#: src/ifhp.c:4052
msgid "Make_stdin_file: cannot fstat fd 1"
msgstr ""

#: src/ifhp.c:4067
#, c-format
msgid "Make_stdin_file: write to tempfile fd %d failed"
msgstr ""

#: src/ifhp.c:4078
msgid "Make_stdin_file: read from stdin"
msgstr ""

#: src/ifhp.c:4092
msgid "Make_stdin_file: lseek failed"
msgstr ""

#: src/ifhp.c:4125
#, c-format
msgid "Fd_readable: cannot fcntl fd %d"
msgstr ""

#: src/ifhp.c:4133
#, c-format
msgid "Fd_readable: fd %d is READ ONLY"
msgstr ""

#: src/ifhp.c:4145
#, c-format
msgid "Fd_readable: cannot fstat fd %d"
msgstr ""

#: src/ifhp.c:4279
msgid "Term_job: job error on cleanup strings"
msgstr ""

#: src/ifhp.c:4301
#, c-format
msgid ""
"Filter_file: WARNING - 'ZOPTS' and 'TOPS' conversion options replaced by {Z} "
"and {T} - '%s'"
msgstr ""

#: src/ifhp.c:4327
msgid "Filter_file: pipe failed"
msgstr ""

#: src/ifhp.c:4334
msgid "Filter_file: fork failed"
msgstr ""

#: src/ifhp.c:4338 src/ifhp.c:4342
msgid "Filter_file: open(/dev/null) failed"
msgstr ""

#: src/ifhp.c:4348
msgid "Filter_file: dup2 failed"
msgstr ""

#. ooops... error
#: src/ifhp.c:4354
#, c-format
msgid "execv '%s' failed - %s"
msgstr ""

#: src/ifhp.c:4369
#, c-format
msgid "Filter_file: started %s- '%s'"
msgstr ""

#: src/ifhp.c:4380
#, c-format
msgid "Filter_file: errbuffer '%s'"
msgstr ""

#: src/ifhp.c:4384 src/ifhp.c:4390
#, c-format
msgid "Filter_file: '%s' error msg '%s'"
msgstr ""

#: src/ifhp.c:4396
msgid "ifhp: waitpid and no child!"
msgstr ""

#: src/ifhp.c:4408
#, c-format
msgid "Filter_file: converter process died with signal %d, '%s'"
msgstr ""
