#if !defined(_CHECKCODE_H_)
#define _CHECKCODE_H_ 1
/* PROTOTYPES */
void Check_code( char *code_str, char *msg, int msglen );

#endif
