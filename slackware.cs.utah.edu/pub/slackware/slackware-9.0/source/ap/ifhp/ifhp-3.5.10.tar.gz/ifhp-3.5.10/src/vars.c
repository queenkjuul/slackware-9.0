/**************************************************************************
 * LPRng IFHP Filter
 * Copyright 1994-1999 Patrick Powell, San Diego, CA <papowell@astart.com>
 **************************************************************************/
/**** HEADER *****/
static char *const _id = "$Id: vars.c,v 1.27 2002/05/01 01:10:39 papowell Exp papowell $";

#define EXTERN
#define DEF
#define DEFINE(X) X
#include "ifhp.h"

/**** ENDINCLUDE ****/

struct keyvalue Valuelist[] = {

    {  "Accounting_info", "accounting_info", &Accounting_info, STRV ,0 },
    {  "Accounting_script", "accounting", &Accounting_script, STRV ,0 },
    {  "Appsocket", "appsocket", (char **)&Appsocket, FLGV ,0 },
    {  "Autodetect", "autodetect", (char **)&Autodetect, FLGV,0 },
    {  "Close_connection", "close_connection", (char **)&Close_connection, FLGV,0 },
    {  "Crlf", "crlf", (char **)&Crlf, FLGV,0 },
    {  "Dev_retries", "dev_retries", (char **)&Dev_retries, INTV,0 },
    {  "Dev_sleep", "dev_sleep", (char **)&Dev_sleep, INTV,0 },
    {  "Device", "dev", &Device, STRV,0 },
    {  "End_status", "end_status", &End_status, STRV,0 },
    {  "Force_conversion", "forceconversion", (char **)&Force_conversion, FLGV,0 },
    {  "Force_processing", "forceprocessing", (char **)&Force_processing, FLGV,0 }, 
    {  "Force_status", "forcestatus", (char **)&Force_status, FLGV,0 },
    {  "Full_time", "fulltime", (char **)&Full_time, FLGV,0 },
    {  "Ignore_eof", "ignore_eof", (char **)&Ignore_eof, FLGV,0 },
    {  "Initial_timeout", "initial_timeout", (char **)&Initial_timeout, INTV,0 },
    {  "Job_timeout", "job_timeout", (char **)&Job_timeout, INTV,0 },
    {  "Logall", "logall", (char **)&Logall, FLGV,0 },
    {  "Max_status_size", "statusfile_max", (char **)&Max_status_size, INTV,0 },
    {  "Min_status_size", "statusfile_min", (char **)&Min_status_size, INTV,0 },
    {  "No_udp_monitor", "no_udp_monitor", (char **)&No_udp_monitor, FLGV,0 },
    {  "Null_pad_count", "nullpad", (char **)&Null_pad_count, INTV,0 },
    {  "Pagecount", "pagecount", &Pagecount, STRV,0 },
    {  "Pagecount_end", "pagecount_end", (char **)&Pagecount_end, FLGV,0 },
    {  "Pagecount_interval", "pagecount_interval", (char **)&Pagecount_interval, INTV,0 },
    {  "Pagecount_poll", "pagecount_poll", (char **)&Pagecount_poll, INTV,0 },
    {  "Pagecount_poll_start", "pagecount_poll_start", (char **)&Pagecount_poll_start, INTV,0 },
    {  "Pagecount_poll_send", "pagecount_poll_end", (char **)&Pagecount_poll_end, INTV,0 },
    {  "Pagecount_start", "pagecount_start", (char **)&Pagecount_start, FLGV,0 },
    {  "Pagecount_timeout", "pagecount_timeout", (char **)&Pagecount_timeout, INTV,0 },
    {  "Pcl", "pcl", (char **)&Pcl, FLGV,0 },
    {  "Pcl_eoj_at_start", "pcl_eoj_at_start", (char **)&Pcl_eoj_at_start, FLGV,0 },
    {  "Pcl_eoj_at_end", "pcl_eoj_at_end", (char **)&Pcl_eoj_at_end, FLGV,0 },
    {  "Pjl", "pjl", (char **)&Pjl, FLGV,0 },
    {  "Pjl_console", "console", (char **)&Pjl_console, FLGV,0 },
    {  "Pjl_console", "pjl_console", (char **)&Pjl_console, FLGV,0 },
    {  "Pjl_display_size", "display_size", (char **)&Pjl_display_size, INTV,0 },
    {  "Pjl_display_size", "pjl_display_size", (char **)&Pjl_display_size, INTV,0 },
    {  "Pjl_done_msg", "pjl_done_msg", &Pjl_done_msg, STRV ,0 },
    {  "Pjl_enter", "pjl_enter", (char **)&Pjl_enter, FLGV,0 },
    {  "Pjl_ready_msg", "pjl_ready_msg", &Pjl_ready_msg, STRV ,0 },
    {  "Ps", "ps", (char **)&Ps, FLGV,0 },
    {  "Ps_ctrl_t", "ps_ctrl_t", (char **)&Ps_ctrl_t, FLGV,0 },
    {  "Ps_eoj", "ps_eoj", (char **)&Ps_eoj, FLGV,0 },
    {  "Ps_eoj_at_end", "ps_eoj_at_start", (char **)&Ps_eoj_at_end, FLGV,0 },
    {  "Ps_eoj_at_start", "ps_eoj_at_start", (char **)&Ps_eoj_at_start, FLGV,0 },
    {  "Ps_pagecount_code", "ps_pagecount_code", &Ps_pagecount_code, STRV,0 },
    {  "Ps_status_code", "ps_status_code", &Ps_status_code, STRV,0 },
    {  "Psonly", "psonly", (char **)&Psonly, FLGV,0 },
    {  "Qms", "qms", (char **)&Qms, FLGV ,0 },
    {  "Remove_ctrl", "remove_ctrl", &Remove_ctrl, STRV ,0 },
    {  "Remove_pjl_at_start", "remove_pjl_at_start", (char **)&Remove_pjl_at_start, FLGV ,0 },
    {  "Status", "status", (char **)&Status, FLGV,0 },
    {  "Stty_args", "stty", &Stty_args, STRV,0 },
    {  "Sync", "sync", &Sync, STRV,0 },
    {  "Sync_interval", "sync_interval", (char **)&Sync_interval, INTV,0 },
    {  "Sync_timeout", "sync_timeout", (char **)&Sync_timeout, INTV,0 },
    {  "Tbcp", "tbcp", (char **)&Tbcp, FLGV,0 },
    {  "Text", "text", (char **)&Text, FLGV,0 },
    {  "Trace_on_stderr", "trace", (char **)&Trace_on_stderr, FLGV,0 },
    {  "Wait_for_banner_page", "wait_for_banner", (char **)&Wait_for_banner, FLGV,0 },
    {  "Waitend", "waitend", &Waitend, STRV,0 },
    {  "Waitend_ctrl_t_interval", "waitend_ctrl_t_interval", (char **)&Waitend_ctrl_t_interval, INTV,0 },
    {  "Waitend_interval", "waitend_interval", (char **)&Waitend_interval, INTV,0 },

    { 0, 0, 0, 0, 0 }
};
