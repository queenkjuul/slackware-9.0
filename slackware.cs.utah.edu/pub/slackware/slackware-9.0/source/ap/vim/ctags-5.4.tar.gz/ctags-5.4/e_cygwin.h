/*
*   $Id: e_cygwin.h,v 1.1 2002/03/08 22:35:19 darren Exp $
*
*   Copyright (c) 2002, Darren Hiebert
*
*   This source code is released for free distribution under the terms of the
*   GNU General Public License.
*
*   Configures ctags for Cygwin environment.
*/
#ifndef E_CYGWIN_H
#define E_CYGWIN_H

#define UNIX_PATH_SEPARATOR 1
#define MSDOS_STYLE_PATH 1

#endif
