/* 
    tags file symbol lookup
    Copyright (C) 1992 Joseph H. Allen

    This file is part of JOE (Joe's Own Editor)
*/

#ifndef _Iutag
#define _Iutag 1

#include "config.h"
#include "bw.h"

int utag(BW * bw);

#endif
