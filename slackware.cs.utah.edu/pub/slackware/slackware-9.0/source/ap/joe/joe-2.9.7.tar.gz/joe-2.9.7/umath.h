#ifndef _Imath
#define _Imath 1

#include "config.h"
#include "bw.h"

extern char *merr;
double calc(BW * bw, char *s);
int umath(BW * bw);

#endif
