/*
	File selection menu
	Copyright (C) 1992 Joseph H. Allen

	This file is part of JOE (Joe's Own Editor)
*/

#ifndef _JOEtab
#define _JOEtab 1

#include "config.h"

#include "bw.h"

int cmplt PARAMS((BW * bw));

#endif
