config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

config etc/magic.new
config etc/magic.mime.new

( cd usr/bin ; rm -rf uncompress )
( cd usr/bin ; ln -sf compress uncompress )
( cd usr/bin ; rm -rf rpm2tgz )
( cd usr/bin ; ln -sf rpm2targz rpm2tgz )
( cd usr/lib ; rm -rf makewhatis )
( cd usr/lib ; ln -sf /usr/sbin/makewhatis makewhatis )
( cd sbin ; rm -rf fsck.reiserfs )
( cd sbin ; ln -sf /bin/true fsck.reiserfs )
( cd sbin ; rm -rf fsck.hpfs )
( cd sbin ; ln -sf /bin/true fsck.hpfs )
( cd sbin ; rm -rf fsck.msdos )
( cd sbin ; ln -sf /bin/true fsck.msdos )
( cd sbin ; rm -rf fsck.umsdos )
( cd sbin ; ln -sf /bin/true fsck.umsdos )
( cd sbin ; rm -rf mkfs.msdos )
( cd sbin ; ln -sf mkdosfs mkfs.msdos )
( cd bin ; rm -rf red )
( cd bin ; ln -sf ed red )
( cd bin ; rm -rf compress )
( cd bin ; ln -sf /usr/bin/compress compress )
