#ifndef MISC_H
#define MISC_H 1
char *load_file(const char *filename);
void report_error(int STATUS, int QUIET, const char *format, ...);

	
#endif /* !MISC_H */
