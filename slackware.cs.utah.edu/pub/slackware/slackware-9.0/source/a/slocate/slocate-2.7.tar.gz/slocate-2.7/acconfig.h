#undef __SunOS__
