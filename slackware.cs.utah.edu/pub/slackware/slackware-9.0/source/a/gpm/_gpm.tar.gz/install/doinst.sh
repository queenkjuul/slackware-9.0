( cd usr/lib ; rm -rf libgpm.so )
( cd usr/lib ; ln -sf ../../lib/libgpm.so.1 libgpm.so )
( cd lib ; rm -rf libgpm.so.1 )
( cd lib ; ln -sf libgpm.so.1.18.0 libgpm.so.1 )
