( cd usr/bin ; rm -rf zipinfo )
( cd usr/bin ; ln -sf unzip zipinfo )
