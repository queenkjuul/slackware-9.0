/* version.h   */

#ifndef VERSION_H
#define VERSION_H
			/* retail */
#define VERSION_MAJOR 22
#define VERSION_MINOR 4 
#define VERSION_EDIT  ".1"
#define VERSION_DATE "27-Jan-2003"

#endif
