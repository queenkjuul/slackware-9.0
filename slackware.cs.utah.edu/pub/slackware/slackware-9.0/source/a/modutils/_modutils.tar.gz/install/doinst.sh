config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}
config etc/modules.conf.new
rm -f etc/modules.conf.new

( cd sbin ; rm -rf ksyms )
( cd sbin ; ln -sf insmod ksyms )
( cd sbin ; rm -rf lsmod )
( cd sbin ; ln -sf insmod lsmod )
( cd sbin ; rm -rf modprobe )
( cd sbin ; ln -sf insmod modprobe )
( cd sbin ; rm -rf rmmod )
( cd sbin ; ln -sf insmod rmmod )
( cd sbin ; rm -rf kallsyms )
( cd sbin ; ln -sf insmod kallsyms )
