/*
 * Copyright (C) 1997-1999 Jeffrey A. Uphoff
 *
 * NSM for Linux.
 */

#define STATD_RELEASE "1.1.1"
