/*
 * popa3d version information.
 */

char popa3d_version[] = "0.6.1";
char popa3d_date[] = "$Date: 2003/03/02 03:38:17 $";
char popa3d_id[] = "@(#) $Id: version.c,v 1.1 2003/03/02 03:38:17 solar Exp $";
