#include <stdio.h>
#include "ipmasqadm.h"

int masqmod_main(int argc, const char *argv[])
{
	printf("\n%s: MODhello\n", argv[0]);
	return 0;
}
