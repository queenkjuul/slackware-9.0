( cd usr/bin ; rm -rf rtin )
( cd usr/bin ; ln -sf tin rtin )
