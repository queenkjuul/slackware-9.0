if [ ! -r etc/inetd.conf ]; then
 mv etc/inetd.conf.new etc/inetd.conf
fi
