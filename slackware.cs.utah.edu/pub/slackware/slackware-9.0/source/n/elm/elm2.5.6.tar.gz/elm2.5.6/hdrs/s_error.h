
#define ErrorSet	0x2
#define ErrorGetoptReq	0x1
#define ErrorCalendarCanOpen	0x2
#define ErrorCalendarAppend	0x3
#define ErrorCalendarSavedPlural	0x4
#define ErrorCalendarSaved	0x5
#define ErrorCalendarNoneSaved	0x6
#define ErrorCalendarSeek	0x7
#define ErrorSystemConnections	0x9
#define ErrorInitCommonNoPasswordEntry	0xa
#define ErrorSafeMallocOutOfMemory	0xb
