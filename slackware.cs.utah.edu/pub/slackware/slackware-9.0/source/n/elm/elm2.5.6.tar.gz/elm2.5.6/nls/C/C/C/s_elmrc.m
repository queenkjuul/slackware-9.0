$set 1 #Elmrc
$ #ExpandHome
1	Can't expand environment variable $HOME to find .elmrc file!\n
$ #OpenElmrc
2	Can't open your ".elmrc" file (%s) for reading!\n
$ #ExpandShell
3	Couldn't expand shell variable $%s in .elmrc!\n
$ #CannotOpenElmrc
4	Error: cannot open "%s" to save. [%s]
$ #CannotOpenRcinfo
5	Warning: cannot open "%s" file.  [%s]
$ #SortOrderCorrupt
6	INTERNAL ERROR: save_info[] sort order corrupt at "%s".
$ #OptionsFile
7	#\n# %s - options file for the ELM mail system\n#\n
$ #SavedAutoFor
8	# Saved automatically by ELM %s for %s\n#\n\n
$ #SavedAuto
9	# Saved automatically by ELM %s\n#\n\n
$ #SavedRaw
10	Due to problems - options being saved as raw, uncommented dump.
$ #UnknownOptionWarning
11	Warning: unknown option "%s" in "%s" file.
$ #UnknownOptionMssg
12	# WARNING - unknown option in "%s"\n
$ #MissingOptionWarning
13	Warning: option "%s" missing from "%s" file.
$ #MissingOptionMssg
14	# WARNING - following option missing from "%s"\n
$ #OptionsSavedIn
15	Options saved in file %s.
$ Do not change the strings ON and OFF in the following message, leave them in English as shown
