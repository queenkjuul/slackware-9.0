$set 6 #Fbrowser
$ this catalog generated automatically by "getcatstrs" - DO NOT EDIT!
$ #CannotBrowse
1	Cannot browse "%s/%s".
$ #HeaderPageOf
2	[page %d/%d]
$ #HeaderDirectory
3	Directory: %s
$ #HeaderPattern
4	Pattern: %s
$ #InstNorm
5	Use "jk+-" to move, "/=~." to enter name, ENTER to select, or q)uit.
$ #InstrDummy1
6	Move the highlighted selection:  j/k = down/up, +/- = down/up page
$ #InstrDummy2
7	Press ENTER to make selection, ? for help, or q)uit.
$quote "
$ #MainPrompt
8	"Command: "
$quote
$ #NoDirectorySaved
9	No directory saved.
$ #AlreadyIn
10	Already in "%s".
$ #LimitInstrNorm
11	Enter new pattern for file listing.
$ #LimitInstrDummy1
12	Enter new pattern for file listing.  Only matching files will be displayed.
$ #LimitInstrDummy2
13	In patterns, "?" means any one char, and "*" means any number of chars.
$quote "
$ #LimitPrompt
14	"New Pattern: "
$quote
$ #NotChanged
15	Not changed.
$ #DirInstrNorm
16	Enter directory to browse.  "~" and "=" ok, CTRL/D to abort
$ #DirInstrDummy1
17	Enter pathname of directory to browse, or CTRL/D to abort entry.
$ #DirInstrDummy2
18	You may say "~" for your home dir and "=" for your folders dir.
$quote "
$ #DirPrompt
19	"New Directory: "
$quote
$ #EnterInstrNorm
20	Enter filename to select, or CTRL/D to abort entry.
$ #EnterInstrDummy1
21	Type in the full name of the file you want, and then press ENTER.
$ #EnterInstrDummy2
22	Press CTRL/D to abort entry and continue browsing.
$quote "
$ #EnterPrompt
23	"Filename: "
$quote
$ #OptionsTitle
24	File Selection Browser -- Options
$ #OptionsTitleDotf
25	D)ot files displayed?
$ #OptionsOn
26	ON
$ #OptionsOff
27	OFF
$ #OptionsSpaceToToggle
28	(SPACE to toggle)
$ #OptionsTitleSort
29	S)orting criteria
$ #OptionsNextOrReverse
30	(SPACE for next, or r)everse)
$ #OptionsInstructDotf
31	Do you want filenames beginning with "." dot to be displayed?
$ #OptionsInstructSort
32	How should the filename listing be sorted?
$ #OptionsInstructMain
33	Select option letter, or q)uit to return to File Selection Browser.
$quote "
$ #OptionsPromptCommand
34	"Command: "
$quote
$ #OptionsBogusSel
35	Wierd!!  curr_sell was %d??  It's fixed now.
$ #OptionsNotChanged
36	Options not changed.
$ #OptionsChangesUndone
37	All option changes have been undone.
$ #EnthdrPermission
38	permission
$ #EnthdrType
39	type
$ #EnthdrOwner
40	owner
$ #EnthdrSize
41	size
$ #EntryDateFmt
42	%y-%b-%d
$ #EnthdrDate
43	date
$ #EnthdrFilename
44	filename
$ #EntryFile
45	file
$ #EntryDir
46	dir
$ #EntryCurrentDir
47	.  [current directory]
$ #EntryParentDir
48	.. [parent directory]
$ #EnterdirCannotRead
49	Cannot read "%s".  [%s]
$ #EnterdirScanning
50	Scanning %s ...
$ #EnterdirRescan
51	Rescan
$ #EnterdirScan
52	Scan
$ #EnterdirSelectedAll
53	%s complete - selected %d entries.
$ #EnterdirSelectedEntries
54	%s complete - selected %d of %d entries.
$ #SorttypeReverse
55	Reverse
$ #SorttypeName
56	Name
$ #SorttypeSize
57	Size
$ #SorttypeDate
58	Date
$ #SorttypeUnknown
59	?Unknown?
$ #MboxCannotGetStatus
60	Cannot get "%s" status.  [%s]
$ #MboxNotRegularFile
61	"%s" is not a regular file.
$ #MboxNoPermissionRead
62	No permission to read "%s".
$ #MboxNoPermissionWrite
63	No permission to write "%s".
$ #NotValidMailbox
64	"%s" is not a valid mailbox.
$ #SafeCopyOverflow
65	Internal Error - buffer not large enough to hold return result.
