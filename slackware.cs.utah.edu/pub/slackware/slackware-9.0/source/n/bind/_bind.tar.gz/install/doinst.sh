# Add a /var/named if it doesn't exist:
if [ ! -d var/named ]; then
  mkdir -p var/named
  chmod 755 var/named
fi
# Add a sample config file if there is none:
if [ ! -r etc/named.conf ]; then
  mv etc/named.conf-sample etc/named.conf
fi
# Generate /etc/rndc.key if there's none there,
# and there also no /etc/rndc.conf (the other
# way to set this up).
if [ ! -r etc/rndc.key -a ! -r /etc/rndc.conf ]; then
  chroot . /sbin/ldconfig
  chroot . /usr/sbin/rndc-confgen -a
fi
