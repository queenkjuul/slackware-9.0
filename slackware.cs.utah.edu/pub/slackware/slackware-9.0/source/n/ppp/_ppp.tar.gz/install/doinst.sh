if [ ! -r etc/ppp/options ]; then
  mv etc/ppp/options.dist etc/ppp/options
fi
