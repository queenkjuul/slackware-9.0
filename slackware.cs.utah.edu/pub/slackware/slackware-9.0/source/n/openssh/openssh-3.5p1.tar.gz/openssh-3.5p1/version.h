/* $OpenBSD: version.h,v 1.35 2002/10/01 13:24:50 markus Exp $ */

#define SSH_VERSION	"OpenSSH_3.5p1"

