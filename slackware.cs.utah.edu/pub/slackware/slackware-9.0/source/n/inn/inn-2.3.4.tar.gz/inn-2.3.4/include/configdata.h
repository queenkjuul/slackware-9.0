/*  $Revision: 1.42 $
**
**  This file is obsolete.  It is present only to allow older INN source
**  that expects it to exist to compile; as soon as all those files have
**  been fixed it will disappear for good.  Everything formerly found here
**  and still needed is now in either clibrary.h (general C functions,
**  macros, and constants) or in acconfig.h (INN-specific things, autoconf
**  results, and system dependencies).
*/

#include "config.h"
