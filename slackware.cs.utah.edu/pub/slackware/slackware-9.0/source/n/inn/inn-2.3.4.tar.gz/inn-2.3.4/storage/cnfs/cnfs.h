/*  $Id: cnfs.h,v 1.6.2.2 2001/02/03 07:30:12 rra Exp $
**
**  cyclic news file system header
*/

#ifndef __CNFS_H__
#define __CNFS_H__

BOOL cnfs_init(SMATTRIBUTE *attr);
TOKEN cnfs_store(const ARTHANDLE article, const STORAGECLASS class);
ARTHANDLE *cnfs_retrieve(const TOKEN token, const RETRTYPE amount);
ARTHANDLE *cnfs_next(const ARTHANDLE *article, const RETRTYPE amount);
void cnfs_freearticle(ARTHANDLE *article);
BOOL cnfs_cancel(TOKEN token);
BOOL cnfs_ctl(PROBETYPE type, TOKEN *token, void *value);
BOOL cnfs_flushcacheddata(FLUSHTYPE type);
void cnfs_printfiles(FILE *file, TOKEN token, char **xref, int ngroups);
void cnfs_shutdown(void);

#endif
