/*  $Id: timehash.h,v 1.8.2.2 2001/02/03 07:28:53 rra Exp $
**
**  timehash based storing method header
*/

#ifndef __TIMEHASH_H__
#define __TIMEHASH_H__

#include <configdata.h>
#include <interface.h>

BOOL timehash_init(SMATTRIBUTE *attr);
TOKEN timehash_store(const ARTHANDLE article, const STORAGECLASS class);
ARTHANDLE *timehash_retrieve(const TOKEN token, const RETRTYPE amount);
ARTHANDLE *timehash_next(const ARTHANDLE *article, const RETRTYPE amount);
void timehash_freearticle(ARTHANDLE *article);
BOOL timehash_cancel(TOKEN token);
BOOL timehash_ctl(PROBETYPE type, TOKEN *token, void *value);
BOOL timehash_flushcacheddata(FLUSHTYPE type);
void timehash_printfiles(FILE *file, TOKEN token, char **xref, int ngroups);
void timehash_shutdown(void);

#endif
