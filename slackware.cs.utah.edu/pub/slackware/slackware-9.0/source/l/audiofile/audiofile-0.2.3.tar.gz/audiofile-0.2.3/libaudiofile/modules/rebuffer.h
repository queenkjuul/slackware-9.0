#ifndef REBUFFER_H
#define REBUFFER_H

_AFmoduleinst initfloatrebufferv2f (AFframecount nsamps, bool multiple_of);
_AFmoduleinst initfloatrebufferf2v (AFframecount nsamps, bool multiple_of);

_AFmoduleinst initint2rebufferv2f (AFframecount nsamps, bool multiple_of);
_AFmoduleinst initint2rebufferf2v (AFframecount nsamps, bool multiple_of);

#endif /* REBUFFER_H */
