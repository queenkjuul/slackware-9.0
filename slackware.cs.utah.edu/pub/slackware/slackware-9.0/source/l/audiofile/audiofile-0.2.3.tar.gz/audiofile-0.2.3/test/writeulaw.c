/*
	Audio File Library

	Copyright (C) 2000, Michael Pruett <michael@68k.org>
	Copyright (C) 2001, Silicon Graphics, Inc.

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

	You should have received a copy of the GNU General Public
	License along with this program; if not, write to the Free
	Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
	MA 02111-1307, USA.
*/

/*
	writeulaw.c

	The writeulaw program performs sanity testing on the Audio File
	Library's G.711 u-law compression by writing and then reading
	back known data to a file to make sure the two sets of data agree.

	This program writes a set of data which is invariant under G.711
	u-law compression to a file and then reads that set of data back.

	The data read from that file should match the data written
	exactly.

	If this test fails, something in the Audio File Library is broken.
*/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef __USE_SGI_HEADERS__
#include <dmedia/audiofile.h>
#else
#include <audiofile.h>
#endif

#include <stdio.h>
#include <unistd.h>

#define TEST_FILE "/tmp/test.ulaw"

#define FRAME_COUNT 16
#define SAMPLE_COUNT FRAME_COUNT

void testulaw (int fileFormat);

void cleanup (void)
{
#ifndef DEBUG
	unlink(TEST_FILE);
#endif
}

void ensure (int condition, const char *message)
{
	if (!condition)
	{
		printf("%s.\n", message);
		cleanup();
		exit(-1);
	}
}

int main (int argc, char **argv)
{
	printf("writeulaw: testing NeXT .snd.\n");
	testulaw(AF_FILE_NEXTSND);
	printf("writeulaw: testing AIFF-C.\n");
	testulaw(AF_FILE_AIFFC);
	printf("writeulaw: testing WAVE.\n");
	testulaw(AF_FILE_WAVE);

	printf("writeulaw test passed.\n");

	exit(0);
}

void testulaw (int fileFormat)
{
	AFfilehandle	file;
	AFfilesetup	setup;
	u_int16_t	samples[] = {8, 16, 80, 120, 180, 780, 924, 988,
			1116, 1436, 1884, 8828, 9852, 15996, 19836, 32124};
	u_int16_t	readsamples[SAMPLE_COUNT];
	AFframecount	framesWritten, framesRead;
	int		i;

	setup = afNewFileSetup();

	afInitCompression(setup, AF_DEFAULT_TRACK, AF_COMPRESSION_G711_ULAW);
	afInitFileFormat(setup, fileFormat);
	afInitChannels(setup, AF_DEFAULT_TRACK, 1);

	file = afOpenFile(TEST_FILE, "w", setup);
	afFreeFileSetup(setup);

	ensure(afGetCompression(file, AF_DEFAULT_TRACK) ==
		AF_COMPRESSION_G711_ULAW,
		"test file not created with G.711 u-law compression");

	ensure(file != AF_NULL_FILEHANDLE, "unable to open file for writing");

	framesWritten = afWriteFrames(file, AF_DEFAULT_TRACK, samples,
		FRAME_COUNT);

	ensure(framesWritten == FRAME_COUNT,
		"number of frames requested does not match number of frames written");
	afCloseFile(file);

	/* Open the file for reading and verify the data. */
	file = afOpenFile(TEST_FILE, "r", NULL);
	ensure(file != AF_NULL_FILEHANDLE, "unable to open file for reading");

	ensure(afGetFileFormat(file, NULL) == fileFormat,
		"test file format incorrect");

	ensure(afGetCompression(file, AF_DEFAULT_TRACK) ==
		AF_COMPRESSION_G711_ULAW,
		"test file not opened with G.711 u-law compression");

	framesRead = afReadFrames(file, AF_DEFAULT_TRACK, readsamples,
		FRAME_COUNT);

	ensure(framesRead == FRAME_COUNT,
		"number of frames read does not match number of frames requested");

#ifdef DEBUG
	for (i=0; i<SAMPLE_COUNT; i++)
		printf("readsamples[%d]: %d\n", i, readsamples[i]);
	for (i=0; i<SAMPLE_COUNT; i++)
		printf("samples[%d]: %d\n", i, samples[i]);
#endif

	for (i=0; i<SAMPLE_COUNT; i++)
	{
		ensure(samples[i] == readsamples[i],
			"data written does not match data read");
	}

	/* G.711 compression uses one byte per sample. */
	ensure(afGetTrackBytes(file, AF_DEFAULT_TRACK) == SAMPLE_COUNT,
		"track byte count is incorrect");

	ensure(afGetFrameCount(file, AF_DEFAULT_TRACK) == FRAME_COUNT,
		"frame count is incorrect");

	ensure(afGetChannels(file, AF_DEFAULT_TRACK) == 1,
		"channel count is incorrect");

	ensure(afCloseFile(file) == 0, "error closing file");

	cleanup();
}
