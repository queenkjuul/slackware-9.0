#ifndef __HAVE_AF_CONFIG_H__
#define __HAVE_AF_CONFIG_H__


/* types substituted/commented-out by configure */
#undef u_int8_t
#undef u_int16_t
#undef u_int32_t


/**************************************************************
 * BEGIN AUTOHEADER-GENERATED SECTION
 **************************************************************/
@TOP@
@BOTTOM@
/**************************************************************
 * END AUTOHEADER-GENERATED SECTION
 **************************************************************/


#endif /* __HAVE_AF_CONFIG_H__ */
