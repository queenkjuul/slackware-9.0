char version[] = "strace -- version 4.4";
