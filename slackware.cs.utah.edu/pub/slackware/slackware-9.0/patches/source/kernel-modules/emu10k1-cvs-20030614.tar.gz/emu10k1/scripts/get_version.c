#include <linux/version.h>
#include <stdio.h>
main()
{
	printf("%s", UTS_RELEASE);
}
