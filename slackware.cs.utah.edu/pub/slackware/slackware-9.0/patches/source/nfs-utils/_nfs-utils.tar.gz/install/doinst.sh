if [ ! -r etc/exports ]; then
  mv etc/exports.new etc/exports
else
  rm -f etc/exports.new
fi
if [ ! -r var/lib/nfs/rmtab ]; then
  touch var/lib/nfs/rmtab
  chmod 644 var/lib/nfs/rmtab
fi
if [ ! -r var/lib/nfs/xtab ]; then
  touch var/lib/nfs/xtab
  chmod 644 var/lib/nfs/xtab
fi
if [ ! -r var/lib/nfs/etab ]; then
  touch var/lib/nfs/etab
  chmod 644 var/lib/nfs/etab
fi
( cd usr/man/man8 ; rm -rf rpc.lockd.8.gz )
( cd usr/man/man8 ; ln -sf lockd.8.gz rpc.lockd.8.gz )
( cd usr/man/man8 ; rm -rf rpc.mountd.8.gz )
( cd usr/man/man8 ; ln -sf mountd.8.gz rpc.mountd.8.gz )
( cd usr/man/man8 ; rm -rf rpc.nfsd.8.gz )
( cd usr/man/man8 ; ln -sf nfsd.8.gz rpc.nfsd.8.gz )
( cd usr/man/man8 ; rm -rf rpc.rquotad.8.gz )
( cd usr/man/man8 ; ln -sf rquotad.8.gz rpc.rquotad.8.gz )
( cd usr/man/man8 ; rm -rf rpc.statd.8.gz )
( cd usr/man/man8 ; ln -sf statd.8.gz rpc.statd.8.gz )
