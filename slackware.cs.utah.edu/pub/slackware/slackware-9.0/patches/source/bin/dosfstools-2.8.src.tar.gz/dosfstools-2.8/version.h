#ifndef _version_h
#define _version_h

#define	VERSION			"2.8"
#define VERSION_DATE	"28 Feb 2001"

#endif  /* _version_h */

