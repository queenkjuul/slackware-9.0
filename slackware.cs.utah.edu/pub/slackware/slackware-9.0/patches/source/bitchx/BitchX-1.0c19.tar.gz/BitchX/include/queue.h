/*
 * queue.h: header for queue.c
 *
 * copyright(c) 1994 matthew green
 *
 * See the copyright file, or do a help ircii copyright 
 *
 * @(#)$Id: queue.h,v 1.1 2001/03/05 19:39:10 nuke Exp $
 */

#ifndef __queue_h
# define __queue_h

	void	queuecmd (char *, char *, char *, char *);

#endif /* __queue_h */
