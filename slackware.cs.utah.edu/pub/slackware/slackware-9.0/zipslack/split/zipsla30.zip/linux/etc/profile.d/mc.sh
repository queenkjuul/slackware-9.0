alias mc='. /usr/share/mc/bin/mc-wrapper.sh'
