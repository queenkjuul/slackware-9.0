#!/bin/sh
# Set the system locale (default C is the same as en_US):
export LANG=C
# This setting has been reported to fix some cut and paste
# problems with GTK2.  If you experience this, try it:
#export LANG=en_US.ISO8859-1
